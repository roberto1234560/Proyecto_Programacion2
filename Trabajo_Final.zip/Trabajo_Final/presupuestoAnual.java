package Trabajo_Final;

import java.util.Scanner;

public class presupuestoAnual {
    public static void main(String[] args) throws ExcepcionActividadChecked {
        Scanner scanner = new Scanner(System.in);
        presupuesto presupuesto = new presupuesto();
        boolean continuar = true;

        while (continuar) {
            System.out.println("\nMenú de Opciones:");
            System.out.println(presupuesto.agregarDisponible() ? "1. Registrar nueva actividad"
                    : "   No se pueden agregar más actividades");
            System.out.println("2. Registrar costo en una actividad");
            System.out.println("3. Eliminar actividad");
            System.out.println("4. Mostrar reporte de actividades");
            System.out.println("5. Salir");

            int opcion = (int) requerirNumero(scanner, "\nElija una opción: ", false);

            switch (opcion) {
                case 1:
                    if (presupuesto.agregarDisponible()) {
                        System.out.print("Nombre de la actividad: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Área de la actividad: ");
                        String area = scanner.nextLine();
                        double montoAsignado = requerirNumero(scanner, "Monto asignado: ", true);
                        System.out.print("Periodo (Primer/Segundo Semestre): ");
                        String periodo = scanner.nextLine();
                        actividad nuevaActividad = new actividad(nombre, area, montoAsignado, periodo);
                        presupuesto.agregarActividad(nuevaActividad);
                    }
                    break;
                case 2:
                    presupuesto.mostrarActividades();
                    int indiceActividadCosto = (int) requerirNumero(scanner,
                            "\n  Seleccione la actividad a modificar(Ingrese número): ", false) - 1;
                    double costo = requerirNumero(scanner, "  Monto consumido: ", true);
                    presupuesto.registrarCosto(indiceActividadCosto, costo);
                    break;
                case 3:
                    presupuesto.mostrarActividades();
                    int indiceActividadEliminar = (int) requerirNumero(scanner,
                            "\n  Seleccione la actividad a eliminar(Ingrese número): ", false) - 1;
                    presupuesto.eliminarActividad(indiceActividadEliminar);
                    break;
                case 4:
                    presupuesto.mostrarReporte();
                    break;
                case 5:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }

        scanner.close();
    }

    private static double requerirNumero(Scanner scanner, String mensaje, boolean permitirDecimales) {
        String numeroSeleccionado;
        do {
            System.out.print(mensaje);
            numeroSeleccionado = scanner.nextLine();
            if (!numeroSeleccionado.isEmpty()) {
                if ((!permitirDecimales && numeroSeleccionado.matches("^\\d+$"))
                        || (permitirDecimales && numeroSeleccionado.matches("^\\d+(\\.\\d+)?$"))) {
                    break;
                } else {
                    System.out.printf("  Valor \"%s\" inválido!\n", numeroSeleccionado);
                }
            }
        } while (true);
        return Double.parseDouble(numeroSeleccionado);
    }
}