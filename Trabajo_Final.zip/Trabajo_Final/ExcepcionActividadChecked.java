package Trabajo_Final;

public class ExcepcionActividadChecked extends Exception{
    public ExcepcionActividadChecked(String message) {
        super(message);
    }
}
