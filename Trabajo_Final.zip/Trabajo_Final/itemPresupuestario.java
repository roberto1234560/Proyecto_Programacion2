package Trabajo_Final;

public class itemPresupuestario {
    protected String nombre;
    protected double montoAsignado;
    protected double montoConsumido;

    public itemPresupuestario(String nombre, double montoAsignado) {
        this.nombre = nombre;
        this.montoAsignado = montoAsignado;
        this.montoConsumido = 0;
    }

    public void registrarCosto(double costo) {
        montoConsumido += costo;
    }

    public double porcentajeRestante() {
        return (1 - (montoConsumido / montoAsignado)) * 100;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean validarLimite() {
        return montoConsumido / montoAsignado >= 0.9;
    }

    public void mostrarItem() {
        System.out.printf(
                "   | %-15s | %10.2f | %10.2f | " +
                        (validarLimite() ? "\u001B[31m%7.2f%%\u001B[0m" : "%7.2f%%") +
                        " |%n",
                nombre, montoAsignado, montoConsumido, porcentajeRestante());
        System.out.println("   ---------------------------------------------------------");
    }
}
