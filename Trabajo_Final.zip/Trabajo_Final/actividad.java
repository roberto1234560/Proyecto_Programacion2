package Trabajo_Final;

public class actividad extends itemPresupuestario {
    private String area;
    private String periodo;

    public actividad(String nombre, String area, double montoAsignado, String periodo) {
        super(nombre, montoAsignado); // Llama al constructor de la clase base
        this.area = area;
        this.periodo = periodo;
    }

    @Override
    public void mostrarItem() {
        System.out.printf(
                "   | %-15s | %-10s | %10.2f | %10.2f | " +
                        (validarLimite() ? "\u001B[31m%7.2f%%\u001B[0m" : "%7.2f%%") +
                        " | %-17s |%n",
                nombre, area, montoAsignado, montoConsumido, porcentajeRestante(), periodo);
        System.out.println(
                "   -----------------------------------------------------------------------------------------");
    }
}