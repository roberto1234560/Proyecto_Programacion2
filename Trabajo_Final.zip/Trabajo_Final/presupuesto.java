package Trabajo_Final;

import java.util.ArrayList;
import java.util.List;

public class presupuesto {
    private static final int MAX_ACTIVIDADES = 10;
    private List<actividad> actividades;

    public presupuesto() {
        this.actividades = new ArrayList<>();
    }

    public boolean agregarDisponible() {
        return actividades.size() < MAX_ACTIVIDADES;
    }

    public void agregarActividad(actividad actividad) {
        if (agregarDisponible()) {
            actividades.add(actividad);
        }
    }

    public void eliminarActividad(int indiceActividad) {
        if (!indiceActividadValido(indiceActividad)) {
            return;
        }
        actividades.remove(indiceActividad);
    }

    public void registrarCosto(int indiceActividad, double costo) throws ExcepcionActividadChecked {
        if (!indiceActividadValido(indiceActividad)) {
            return;
        }
        actividad actividad = actividades.get(indiceActividad);
        actividad.registrarCosto(costo);
        if (actividad.validarLimite()) {
            throw new ExcepcionActividadChecked("Alerta! La actividad alcanzó o superó el 90%% del presupuesto asignado.");
        }
    }

    public void mostrarReporte() {
        System.out.println("\n  Reporte:");
        System.out.println(
                "   -----------------------------------------------------------------------------------------");
        System.out.printf("   | %-15s | %-10s | %10s | %10s | %6s | %-17s |%n",
                "Nombre", "Área", "Asignado", "Consumido", "Restante", "Periodo");
        System.out.println(
                "   -----------------------------------------------------------------------------------------");
        for (actividad actividad : actividades) {
            actividad.mostrarItem();
        }
    }

    public void mostrarActividades() {
        System.out.println("  Actividades registradas:");
        for (int i = 0; i < actividades.size(); i++) {
            System.out.printf("  %d: %-5s %n", i + 1, actividades.get(i).getNombre());
        }
    }

    private boolean indiceActividadValido(int indiceActividad) {
        if (indiceActividad < 0 || indiceActividad >= actividades.size()) {
            System.out.println("   Actividad seleccionada no válida.");
            return false;
        }
        return true;
    }
}